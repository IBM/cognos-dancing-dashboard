define([
	'jquery',
	'dashboard/widgets/CustomWidget',
	'http://d3js.org/d3.v4.min.js'
], function( $, Base, d3) {

	var Widget = Base.extend({
		onInit: function(params) {
			this.name = params.name;
		},
		onRender: function() {
			var root = this.getContentRootNode();
			//alert("onRender Func");
			//$(root).append('<style>' + CSS + '</style>');
			$(root).append('<h1 class="titleColor titleFontSize"> Report of ' + this.name + ' for last 24 Hours</h1><br/>');
			$(root).append('<div id="tableContainer" class="tableContainer"></div><br/>');
			$(root).append('<div id="noteContainer" class="noteContainer">*Note: Click on an attribute column to see live streaming for that attribute. </div>');
			$(root).append('<div id="linechart" class="linechart"></div><br/>');
			//$(root).append('<div id="livelinechart" class="livelinechart"></div>');
			drawTable();
			drawChart1();
			//drawChart2();
			//alert ("after func call");
		}
	});
    
	function drawTable(){
		//alert("in drawTable Func");
		var content = "<table>";
		var i;
		content += "<thead> <th>S.No.</th> <th>Pressure</th> <th>Temperature</th> <th>Vibration</th> <th>Time</th> <th>Date</th></thead>";
		content += "<tbody>";
		//content += "<tr> <td>1</td> <td>20</td> <td>25</td>";
		for (i=0; i<20; i++) {
			content += "<tr>";
			content += "<td>" + (i+1) + "</td>";
			content += "<td>" + i*10 + "</td>";
			content += "<td>" + i*20 + "</td>";
			content += "<td>" + i*30 + "</td>";
			content += "<td>" + "time" + "</td>";
			content += "<td>" + "date" + "</td>";
			content += "</tr>";
		}
		content += "</table>";
		$('#tableContainer').append( content );
		
	}
	
    function drawChart1() {
        //alert("in chart1 function");

        var margin = {top: 50, right: 50, bottom: 50, left: 50}
                    , width = 400 - margin.left - margin.right // Use the window's width 
                    , height = 400 - margin.top - margin.bottom;

        // The number of datapoints
        var n = 10;

        // 5. X scale will use the index of our data
        var xScale = d3.scaleLinear()
            .domain([0, n-1]) // input
            .range([0, width]); // output

        // 6. Y scale will use the randomly generate number 
        var yScale = d3.scaleLinear()
            .domain([0, 1]) // input 
            .range([height, 0]); // output 

        // 7. d3's line generator
        var line = d3.line()
            .x(function(d, i) { return xScale(i); }) // set the x values for the line generator
            .y(function(d) { return yScale(d.y); }) // set the y values for the line generator 
            .curve(d3.curveMonotoneX) // apply smoothing to the line

        // 8. An array of objects of length N. Each object has key -> value pair, the key being "y" and the value is a random number
        var dataset = d3.range(n).map(function(d) { return {"y": d3.randomUniform(1)() } })
        
        // 1. Add the SVG to the page and employ #2
        var svg = d3.select("#linechart").append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            //.attr("style", "outline: thin solid red;") 
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        // 3. Call the x axis in a group tag
        svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + height + ")")
            .call(d3.axisBottom(xScale)); // Create an axis component with d3.axisBottom

        // 4. Call the y axis in a group tag
        svg.append("g")
            .attr("class", "y axis")
            .call(d3.axisLeft(yScale)); // Create an axis component with d3.axisLeft

        // 9. Append the path, bind the data, and call the line generator 
        svg.append("path")
            .datum(dataset) // 10. Binds data to the line 
            .attr("class", "line") // Assign a class for styling
			//.attr("stroke-width", 1)
			//.attr("stroke", "red")
			//.attr("fill","none")
			//.style("fill","none")
            .attr("d", line); // 11. Calls the line generator 

        // 12. Appends a circle for each datapoint 
        svg.selectAll(".dot")
            .data(dataset)
            .enter().append("circle") // Uses the enter().append() method
            .attr("class", "dot") // Assign a class for styling
            .attr("cx", function(d, i) { return xScale(i) })
            .attr("cy", function(d) { return yScale(d.y) })
			//.attr("stroke", "blue")
			//.attr("fill", "blue")
            .attr("r", 3);

    }


	function drawChart2() {
		alert("in chart2 function");
        var data = [
    ];
    var width = 400;
    var height = 400;
    var globalX = 0;
    var duration = 500;
    var max = 500;
    var step = 10;
    var chart = d3.select("#livelinechart").append("svg")
    .attr('width', width + 50)
    .attr('height', height + 50);
    var x = d3.scaleLinear().domain([0, 500]).range([0, 300]);
    var y = d3.scaleLinear().domain([0, 500]).range([300, 0]);
    // -----------------------------------
    var line = d3.line()
					    .x(function(d){ return x(d.x); })
					    .y(function(d){ return y(d.y); });
    var smoothLine = d3.line().curve(d3.curveCardinal)
					    .x(function(d){ return x(d.x); })
					    .y(function(d){ return y(d.y); });
    var lineArea = d3.area()
					    .x(function(d){ return x(d.x); })
					    .y0(y(0))
					    .y1(function(d){ return y(d.y); })
					    .curve(d3.curveCardinal);
    // -----------------------------------
    // Draw the axis
    var xAxis = d3.axisBottom().scale(x);
    var axisX = chart.append('g').attr('class', 'x axis')
				.attr("font-family", "sans-serif")
				.attr("fill", "#d35400")
				.attr("font-size", "12px")
			     .attr('transform', 'translate(0, 300)')
			     .call(xAxis);
    // Draw the grid
    chart.append('path').datum([{x: 0, y: 150}, {x: 300, y: 150}])
					    .attr('class', 'grid')
						.attr("stroke", "#DDD")
						.attr("stroke-width", 1)
						.attr("fill", "none")
					    .attr('d', line);
    chart.append('path').datum([{x: 0, y: 300}, {x: 500, y: 300}])
					    .attr('class', 'grid')
						.attr("stroke", "#DDD")
						.attr("stroke-width", 1)
						.attr("fill", "none")
					    .attr('d', line);
    chart.append('path').datum([{x: 0, y: 450}, {x: 500, y: 450}])
					    .attr('class', 'grid')
						.attr("stroke", "#DDD")
						.attr("stroke-width", 1)
						.attr("fill", "none")
					    .attr('d', line);
    chart.append('path').datum([{x: 50, y: 0}, {x: 50, y: 500}])
					    .attr('class', 'grid')
						.attr("stroke", "#DDD")
						.attr("stroke-width", 1)
						.attr("fill", "none")
					    .attr('d', line);
    chart.append('path').datum([{x: 250, y: 0}, {x: 250, y: 500}])
					    .attr('class', 'grid')
						.attr("stroke", "#DDD")
						.attr("stroke-width", 1)
						.attr("fill", "none")
					    .attr('d', line);
    chart.append('path').datum([{x: 450, y: 0}, {x: 450, y: 500}])
					    .attr('class', 'grid')
						.attr("stroke", "#DDD")
						.attr("stroke-width", 1)
						.attr("fill", "none")
					    .attr('d', line);
    // Append the holder for line chart and fill area
    var path = chart.append('path');
    var areaPath = chart.append('path');
    // Main loop
    function tick() {
	    // Generate new data
	    var point = {
		    x: globalX,
		    y: ((Math.random() * 450 + 50) >> 0)
	    };
	    data.push(point);
	    globalX += step;
	    // Draw new line
	    path.datum(data)
		    .attr('class', 'smoothline')
			.attr("stroke", "#e74c3c")
			.attr("stroke-width", 3)
			.attr("fill", "none")
		    .attr('d', smoothLine);
	    // Draw new fill area
	    areaPath.datum(data)
		    .attr('class', 'area')
			.attr("opacity", 0.5)
			.attr("fill", "#e74c3c")
		    .attr('d', lineArea);
	    // Shift the chart left
	    x.domain([globalX - (max - step), globalX]);
	    axisX.transition()
		     .duration(duration)
		     .ease(d3.easeLinear,2)
		     .call(xAxis);
	    path.attr('transform', null)
		    .transition()
		    .duration(duration)
		    .ease(d3.easeLinear,2)
		    .attr('transform', 'translate(' + x(globalX - max) + ')')
	    areaPath.attr('transform', null)
		    .transition()
		    .duration(duration)
		    .ease(d3.easeLinear,2)
		    .attr('transform', 'translate(' + x(globalX - max) + ')')
		    .on('end', tick)
	    // Remote old data (max 50 points)
	    if (data.length > 50) data.shift();
    }
    tick();
	}
	
	return Widget;
});